--------------------
NotFoundParamAlert
--------------------
Author: Kudashev Serge <kudashevs@gmail.com>
--------------------

MODx Revolution plugin which generate alert on page not found with specified parameters in URL.
Useful to catch wrong URLs on large context advertising projects with UTM or other parameters.

--------------------
Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/kudashevs/NotFoundParamAlert/issues