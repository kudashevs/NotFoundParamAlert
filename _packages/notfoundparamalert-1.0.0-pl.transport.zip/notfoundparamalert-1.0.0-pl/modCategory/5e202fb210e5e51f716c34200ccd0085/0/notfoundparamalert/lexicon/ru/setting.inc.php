<?php
$_lang['area_notfoundparamalert.main'] = 'Основные';

$_lang['setting_notfoundparamalert.parameters'] = 'URL параметры';
$_lang['setting_notfoundparamalert.parameters_desc'] = 'Список параметров URL через запятую, которые будут вызывать уведомление.';
$_lang['setting_notfoundparamalert.alert_method'] = 'Способ уведомления';
$_lang['setting_notfoundparamalert.alert_method_desc'] = 'Способ уведоваления доставки сгенерированного уведомления. Доступные значения: "log", "mail", "both".';
$_lang['setting_notfoundparamalert.email_to'] = 'Email to';
$_lang['setting_notfoundparamalert.email_to_desc'] = 'Введите валидный email адрес куда будут отправляться сообщения.';