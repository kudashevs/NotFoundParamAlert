<?php
$_lang['email_subject'] = 'Page not found';
$_lang['email_body'] = 'NotFoundParamAlert alert: on site [[+siteUrl]] not found page [[+urlPath]]<br />requested with parameters: [[+requestParams]]<br />with alert method [[+alertMethod]] requested from [[+ipAddress]]';