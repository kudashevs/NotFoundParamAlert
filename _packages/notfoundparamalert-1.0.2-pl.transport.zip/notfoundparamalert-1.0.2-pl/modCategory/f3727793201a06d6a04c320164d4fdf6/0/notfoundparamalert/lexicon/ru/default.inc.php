<?php
$_lang['email_subject'] = 'Страница не найдена';
$_lang['email_body'] = 'NotFoundParamAlert уведомление: на сайте [[+siteUrl]] не найдена страница [[+urlPath]]<br />запрошенная с параметрами: [[+requestParams]]<br />с способом уведомления [[+alertMethod]] запрошенная с [[+ipAddress]]';