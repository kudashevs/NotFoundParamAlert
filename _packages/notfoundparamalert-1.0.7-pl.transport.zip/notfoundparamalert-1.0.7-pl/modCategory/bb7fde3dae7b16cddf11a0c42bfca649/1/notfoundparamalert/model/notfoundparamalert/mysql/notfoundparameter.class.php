<?php
require_once (dirname(__DIR__) . '/notfoundparameter.class.php');
class NotFoundParameter_mysql extends NotFoundParameter {}