<?php
class NotFoundParameter extends xPDOSimpleObject {}