<?php

$_lang['notfoundparamalert'] = 'NotFoundParamAlert';
$_lang['notfoundparamalert_menu_desc'] = 'Управление собранными данными';
$_lang['notfoundparamalert_id'] = 'ID';
$_lang['notfoundparamalert_url_full'] = 'Полный URL';
$_lang['notfoundparamalert_parameters_all'] = 'Все параметры';
$_lang['notfoundparamalert_parameters_found'] = 'Найденный параметры';
$_lang['notfoundparamalert_parameters_pattern'] = 'Правила';
$_lang['notfoundparamalert_ip_address'] = 'IP Адрес';
$_lang['notfoundparamalert_timestamp'] = 'Дата и время';
$_lang['notfoundparamalert_item_show'] = 'Показать запись';
$_lang['notfoundparamalert_item_remove']  = 'Удалить запись';
$_lang['notfoundparamalert_item_remove_confirm']  = 'Вы уверены что хотите удалить эту запись?';
$_lang['notfoundparamalert_items_remove']  = 'Удалить записи';
$_lang['notfoundparamalert_items_remove_confirm']  = 'Вы уверены что хотите удалить выбранные записи?';