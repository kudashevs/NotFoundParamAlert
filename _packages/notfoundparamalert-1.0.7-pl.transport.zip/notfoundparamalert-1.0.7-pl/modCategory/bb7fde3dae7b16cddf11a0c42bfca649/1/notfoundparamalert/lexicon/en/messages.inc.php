<?php

$_lang['log_message'] = '[[+alertName]] page [[+urlFull]] requested with parameters: [[+requestParams]] was not found on site [[+siteName]] alert method [[+alertMethod]] from IP address [[+ipAddress]]';
$_lang['email_subject'] = '[[+alertName]] params not found';
$_lang['email_body'] = 'Page [[+urlFull]] not found on site [[+siteName]]<br />requested parameters: [[+requestParams]]<br />alert method [[+alertMethod]] IP address [[+ipAddress]]';