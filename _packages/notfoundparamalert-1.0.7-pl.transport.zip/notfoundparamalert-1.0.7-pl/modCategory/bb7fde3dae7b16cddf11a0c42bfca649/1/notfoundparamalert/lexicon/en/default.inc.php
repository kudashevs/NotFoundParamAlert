<?php

$_lang['notfoundparamalert'] = 'NotFoundParamAlert';
$_lang['notfoundparamalert_menu_desc'] = 'Manage collected data';
$_lang['notfoundparamalert_id'] = 'ID';
$_lang['notfoundparamalert_url_full'] = 'Full URL';
$_lang['notfoundparamalert_parameters_all'] = 'All parameters';
$_lang['notfoundparamalert_parameters_found'] = 'Founded parameters';
$_lang['notfoundparamalert_parameters_pattern'] = 'Used rules';
$_lang['notfoundparamalert_ip_address'] = 'IP Address';
$_lang['notfoundparamalert_timestamp'] = 'Date and time';
$_lang['notfoundparamalert_item_show'] = 'Show record';
$_lang['notfoundparamalert_item_remove']  = 'Delete record';
$_lang['notfoundparamalert_item_remove_confirm']  = 'Are you sure to delete this record?';
$_lang['notfoundparamalert_items_remove']  = 'Delete records';
$_lang['notfoundparamalert_items_remove_confirm']  = 'Are you sure to delete selected records?';