<?php

$_lang['log_message'] = '[[+alertName]] страница [[+urlFull]] запрошенная с параметрами: [[+requestParams]] не найдена на сайте [[+siteName]] способ уведомления [[+alertMethod]] IP адрес [[+ipAddress]]';
$_lang['email_subject'] = '[[+alertName]] параметр не найден';
$_lang['email_body'] = 'Страница [[+urlFull]] не найдена на сайте [[+siteName]]<br />была запрошена с параметрами: [[+requestParams]]<br />способ уведомления [[+alertMethod]] IP адрес [[+ipAddress]]';